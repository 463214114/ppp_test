{
    libsPath: "https://sdk.cloudroom.com/web/live/libs/",
    acssvrPort: 8080,
}